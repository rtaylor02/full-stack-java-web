package com.rtaylor02.touristreviewapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TouristReviewAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(TouristReviewAppApplication.class, args);
	}

}
